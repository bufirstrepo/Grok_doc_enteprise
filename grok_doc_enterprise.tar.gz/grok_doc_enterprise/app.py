# app.py – Grok_doc_enterprise Streamlit Interface
# Production-grade UI for PhD-level multi-LLM tribunal

import streamlit as st
import logging
from datetime import datetime
from src.llm_chain import run_llm_chain

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# ══════════════════════════════════════════════════════════════════════════════
# PAGE CONFIGURATION
# ══════════════════════════════════════════════════════════════════════════════
st.set_page_config(
    page_title="Grok Doc v3.0 - Clinical AI Tribunal",
    page_icon="🏥",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ══════════════════════════════════════════════════════════════════════════════
# SESSION STATE INITIALIZATION
# ══════════════════════════════════════════════════════════════════════════════
if "physician_id" not in st.session_state:
    st.session_state.physician_id = f"PHY_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
if "chain_mode" not in st.session_state:
    st.session_state.chain_mode = True
if "history" not in st.session_state:
    st.session_state.history = []

# ══════════════════════════════════════════════════════════════════════════════
# SIDEBAR CONFIGURATION
# ══════════════════════════════════════════════════════════════════════════════
with st.sidebar:
    st.title("⚙️ Configuration")
    
    st.session_state.physician_id = st.text_input(
        "Physician ID",
        value=st.session_state.physician_id,
        help="Unique identifier for audit trail"
    )
    
    st.session_state.chain_mode = st.checkbox(
        "Enable 4-Stage Tribunal",
        value=st.session_state.chain_mode,
        help="Execute full adversarial chain vs single-model inference"
    )
    
    st.divider()
    
    st.subheader("📊 System Status")
    st.metric("Session Queries", len(st.session_state.history))
    st.metric("Physician ID", st.session_state.physician_id)
    
    st.divider()
    
    if st.button("🗑️ Clear History", use_container_width=True):
        st.session_state.history = []
        st.rerun()
    
    st.divider()
    
    st.caption("**Grok Doc v3.0 Enterprise**")
    st.caption("HIPAA-Compliant | Zero-Cloud | Blockchain Audit")

# ══════════════════════════════════════════════════════════════════════════════
# MAIN INTERFACE
# ══════════════════════════════════════════════════════════════════════════════
st.title("🏥 Grok Doc v3.0 - Adversarial Clinical AI")
st.caption("PhD-Grade Multi-LLM Tribunal for Clinical Decision Support")

# ── Input Section ──
st.subheader("📝 Clinical Note Input")

note_text = st.text_area(
    "Enter clinical note, patient data, or query:",
    height=200,
    placeholder="Example: Patient presents with fever (101.2°F), productive cough x3 days, "
                "SOB on exertion. PMH: asthma. Current meds: albuterol PRN. Vitals stable. "
                "Considering antibiotic therapy vs viral supportive care...",
    help="Free-text input for diagnostic analysis. System will extract relevant clinical entities."
)

col1, col2, col3 = st.columns([2, 1, 1])

with col1:
    analyze_btn = st.button("🔬 Analyze", type="primary", use_container_width=True)

with col2:
    voice_btn = st.button("🎤 Voice Input", use_container_width=True, disabled=True)
    if voice_btn:
        st.info("Voice input requires mobile app connection")

with col3:
    ehr_btn = st.button("📋 Load from EHR", use_container_width=True, disabled=True)
    if ehr_btn:
        st.info("EHR integration pending Epic RPA configuration")

# ══════════════════════════════════════════════════════════════════════════════
# CHAIN EXECUTION & RESULT RENDERING
# ══════════════════════════════════════════════════════════════════════════════
if analyze_btn and note_text.strip():
    try:
        if st.session_state.chain_mode:
            # ── MULTI-LLM TRIBUNAL MODE ──
            with st.spinner("Executing 4-stage adversarial tribunal..."):
                result = run_llm_chain(note_text, st.session_state.physician_id)
            
            status = result["chain_status"]
            
            # ── SUCCESS: Full Tribunal Consensus ──
            if status == "success":
                st.success("✅ Full Tribunal Consensus Achieved")
                
                col1, col2, col3 = st.columns([3, 1, 1])
                with col1:
                    st.markdown(f"**Final Recommendation:** {result['final_recommendation']}")
                with col2:
                    st.metric("Consensus Confidence", f"{result['consensus_confidence']:.1%}")
                with col3:
                    st.metric("Execution Time", f"{result['total_execution_time_ms']:.0f}ms")
                
                # Show stage completion badges
                st.markdown("**Completed Stages:**")
                stage_cols = st.columns(4)
                for idx, stage in enumerate(["kinetics", "adversarial", "literature", "arbiter"]):
                    with stage_cols[idx]:
                        if stage in result["completed_stages"]:
                            exec_time = result[stage]["_stage_metadata"]["execution_time_ms"]
                            st.success(f"✓ {stage.title()}\n{exec_time:.0f}ms")
                        else:
                            st.error(f"✗ {stage.title()}")
            
            # ── PARTIAL: Some Stages Failed ──
            elif status == "partial":
                st.warning("⚠️ Partial Tribunal – Use with Enhanced Clinical Oversight")
                
                col1, col2 = st.columns(2)
                with col1:
                    st.info(f"**Completed:** {', '.join([s.title() for s in result['completed_stages']])}")
                with col2:
                    st.error(f"**Failed at:** {result['failed_stage'].title()} stage")
                
                # Show partial recommendation if Kinetics completed
                if "kinetics" in result["completed_stages"]:
                    k = result["kinetics"]
                    st.markdown(f"**Partial Recommendation (Kinetics only):** {k.get('recommendation', 'N/A')}")
                    
                    col1, col2 = st.columns(2)
                    with col1:
                        st.metric("Partial Confidence", f"{k.get('confidence', 0):.1%}")
                    with col2:
                        st.metric("Execution Time", f"{result['total_execution_time_ms']:.0f}ms")
                    
                    st.warning(
                        "⚠️ **Clinical Notice:** Full multi-LLM verification incomplete. "
                        "This recommendation lacks adversarial review and literature validation. "
                        "**Escalate to senior review** before implementation."
                    )
                else:
                    st.error(
                        "❌ Chain failed before initial diagnostic output. "
                        "No clinical recommendations available."
                    )
                
                # Show error details
                with st.expander("⚠️ View Error Details", expanded=False):
                    st.code(result.get("error", "Unknown error"), language="text")
                    if "error_trace" in result:
                        st.code(result["error_trace"], language="python")
            
            # ── FAILED: Complete Chain Failure ──
            else:  # "failed"
                st.error("❌ Chain Execution Failed Completely")
                st.error(f"**Failed at:** {result.get('failed_stage', 'Unknown').title()} stage")
                st.code(result.get("error", "Unknown error"), language="text")
                
                if "error_trace" in result:
                    with st.expander("View Full Stack Trace"):
                        st.code(result["error_trace"], language="python")
            
            # ── PROVENANCE VIEWER (Always Available) ──
            st.divider()
            with st.expander("🔍 View Full Tribunal Provenance & Stage Outputs", expanded=False):
                tabs = st.tabs(["Kinetics", "Adversarial", "Literature", "Arbiter", "Metadata"])
                
                for idx, stage in enumerate(["kinetics", "adversarial", "literature", "arbiter"]):
                    with tabs[idx]:
                        if stage in result:
                            st.subheader(f"{stage.title()} Stage Output")
                            
                            # Show execution metadata if available
                            if "_stage_metadata" in result[stage]:
                                meta = result[stage]["_stage_metadata"]
                                col1, col2, col3 = st.columns(3)
                                with col1:
                                    st.metric("Execution Time", f"{meta['execution_time_ms']:.0f}ms")
                                with col2:
                                    st.metric("Retry Count", meta['retry_count'])
                                with col3:
                                    st.metric("Timestamp", meta['timestamp'].split('T')[1][:8])
                            
                            st.json(result[stage], expanded=False)
                        else:
                            st.info(f"{stage.title()} stage not reached")
                
                # Metadata tab
                with tabs[4]:
                    st.subheader("Chain Execution Metadata")
                    meta_data = {
                        "Chain Status": result["chain_status"],
                        "Physician ID": result["physician_id"],
                        "Completed Stages": result["completed_stages"],
                        "Failed Stage": result.get("failed_stage", "None"),
                        "Total Execution Time": f"{result['total_execution_time_ms']:.2f}ms"
                    }
                    st.json(meta_data)
                    
                    if result.get("error"):
                        st.error("**Error Details:**")
                        st.code(result["error"], language="text")
            
            # Add to history
            st.session_state.history.append({
                "timestamp": datetime.now().isoformat(),
                "input": note_text[:100] + "..." if len(note_text) > 100 else note_text,
                "status": result["chain_status"],
                "recommendation": result.get("final_recommendation") or result.get("kinetics", {}).get("recommendation", "N/A")
            })
        
        else:
            # ── SINGLE-MODEL MODE (for comparison) ──
            st.info("Single-model mode (Kinetics only) - for performance comparison")
            with st.spinner("Running single-model inference..."):
                from src.llm_chain import kinetics_model
                result = kinetics_model(note_text)
            
            st.markdown(f"**Recommendation:** {result['recommendation']}")
            st.metric("Confidence", f"{result['confidence']:.1%}")
            st.json(result, expanded=False)
    
    except Exception as e:
        # This should now NEVER trigger — all errors are caught inside run_llm_chain
        st.error("❌ Unexpected application error – contact system administrator")
        logger.critical("Uncaught exception in chain UI", exc_info=True)
        st.code(str(e), language="text")

elif analyze_btn and not note_text.strip():
    st.warning("⚠️ Please enter clinical note text before analysis")

# ══════════════════════════════════════════════════════════════════════════════
# QUERY HISTORY
# ══════════════════════════════════════════════════════════════════════════════
if st.session_state.history:
    st.divider()
    st.subheader("📜 Recent Query History")
    
    for idx, item in enumerate(reversed(st.session_state.history[-5:])):
        with st.expander(
            f"Query {len(st.session_state.history) - idx}: {item['input'][:50]}... "
            f"[{item['status'].upper()}]",
            expanded=False
        ):
            col1, col2 = st.columns([3, 1])
            with col1:
                st.markdown(f"**Recommendation:** {item['recommendation']}")
            with col2:
                st.metric("Status", item['status'].upper())
            st.caption(f"Timestamp: {item['timestamp']}")

# ══════════════════════════════════════════════════════════════════════════════
# FOOTER
# ══════════════════════════════════════════════════════════════════════════════
st.divider()
st.caption(
    "⚠️ **Clinical Disclaimer:** This system provides decision support only. "
    "All recommendations must be reviewed by licensed clinicians. "
    "For emergency care, contact appropriate emergency services immediately."
)
st.caption("🔒 HIPAA-Compliant | Zero-Cloud Architecture | Blockchain Audit Trail")
