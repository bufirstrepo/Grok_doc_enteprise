#!/bin/bash
# Grok Doc v3.0 - Quick Start Script

echo "🏥 Grok Doc v3.0 Enterprise - Quick Start"
echo "========================================"

# Check Python version
echo "✓ Checking Python version..."
python3 --version

# Create virtual environment
echo "✓ Creating virtual environment..."
python3 -m venv venv
source venv/bin/activate

# Install dependencies
echo "✓ Installing dependencies..."
pip install -r requirements.txt

# Copy environment template
echo "✓ Setting up environment..."
cp .env.example .env
echo "⚠️  Edit .env with your API keys before running!"

# Run application
echo "✓ Ready to launch!"
echo ""
echo "Next steps:"
echo "  1. Edit .env with your API keys"
echo "  2. Run: streamlit run app.py"
echo "  3. Navigate to http://localhost:8501"
echo ""
echo "📖 Read IMPLEMENTATION_SUMMARY.md for full details"
